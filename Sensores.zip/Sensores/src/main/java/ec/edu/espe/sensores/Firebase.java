package ec.edu.espe.sensores;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import java.io.FileInputStream;
import java.io.IOException;

public class Firebase
{
    private static Firebase instance = null;

    private Firebase() throws IOException
    {
        FileInputStream fileInputStream = new FileInputStream("key.json");
        FirebaseOptions.Builder optionsBuilder = new FirebaseOptions.Builder();
        optionsBuilder.setCredentials(GoogleCredentials.fromStream(fileInputStream));
        optionsBuilder.setDatabaseUrl("https://tecno-dd2ad.firebaseio.com");
        FirebaseOptions firebaseOptions = optionsBuilder.build();
        FirebaseApp.initializeApp(firebaseOptions);
    }

    public static Firebase getInstance()
    {
        try
        {
            if (FirebaseApp.getApps().isEmpty())
            {
                instance = new Firebase();
            }
            return instance;
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
            return null;
        }
    }

}
