package ec.edu.espe.sensores;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import javax.swing.table.DefaultTableModel;

public class Ventana extends javax.swing.JFrame
{

    private Float valoresHumedad = 0F;
    private Float valoresProximidad = 0F;
    private Float valoresTemperatura = 0F;

    public Ventana()
    {
        initComponents();
        setVisible(true);
        iniciarSensorHumedad();
        iniciarSensorProximidad();
        iniciarSensorTemperatura();

    }

    private void iniciarSensorHumedad()
    {
        Firebase.getInstance();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("valorHumedad");
        database.addValueEventListener(new ValueEventListener()
        {

            @Override
            public void onDataChange(DataSnapshot ds)
            {
                Object document = ds.getValue();
                labelHumedad.setText("Sensor Humedad: " + document);
                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                String[] row = new String[3];
                if (model.getRowCount() > 0)
                {
                    row[0] = document.toString();
                    row[1] = (String) model.getValueAt(model.getRowCount() - 1, 1);
                    row[2] = (String) model.getValueAt(model.getRowCount() - 1, 2);
                }
                else
                {
                    row[0] = document.toString();
                    row[1] = "0";
                    row[2] = "0";
                }

                model.addRow(row);
            }

            @Override
            public void onCancelled(DatabaseError de)
            {
                System.out.println("Actualizacion cancelada");
            }
        });
    }

    private void iniciarSensorProximidad()
    {
        Firebase.getInstance();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("valorProximidad");
        database.addValueEventListener(new ValueEventListener()
        {

            @Override
            public void onDataChange(DataSnapshot ds)
            {
                Object document = ds.getValue();
                labelProximidad.setText("Sensor Proximidad: " + document);
                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                String[] row = new String[3];
                if (model.getRowCount() > 0)
                {
                    row[0] = (String) model.getValueAt(model.getRowCount() - 1, 0);
                    row[1] = document.toString();
                    row[2] = (String) model.getValueAt(model.getRowCount() - 1, 2);
                }
                else
                {
                    row[0] = "0";
                    row[1] = document.toString();
                    row[2] = "0";
                }

                model.addRow(row);
            }

            @Override
            public void onCancelled(DatabaseError de)
            {
                System.out.println("Actualizacion cancelada");
            }
        });
    }

    private void iniciarSensorTemperatura()
    {
        Firebase.getInstance();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("valorTemperatura");
        database.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot ds)
            {
                Object document = ds.getValue();
                labelTemperatura.setText("Sensor Temperatura: " + document);
                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                String[] row = new String[3];
                if (model.getRowCount() > 0)
                {
                    row[0] = (String) model.getValueAt(model.getRowCount() - 1, 0);
                    row[1] = (String) model.getValueAt(model.getRowCount() - 1, 1);
                    row[2] = document.toString();
                }
                else
                {
                    row[0] = "0";
                    row[1] = "0";
                    row[2] = document.toString();
                }

                model.addRow(row);
            }

            @Override
            public void onCancelled(DatabaseError de)
            {
                System.out.println("Actualizacion cancelada");
            }
        });
    }

    public void agregarFila(Float humedad, Float proximidad, Float temperatura)
    {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        String[] row = new String[3];
        row[0] = humedad.toString();
        row[1] = proximidad.toString();
        row[2] = temperatura.toString();
        model.addRow(row);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jLabel1 = new javax.swing.JLabel();
        labelHumedad = new javax.swing.JLabel();
        labelProximidad = new javax.swing.JLabel();
        labelTemperatura = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(550, 300));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        jLabel1.setText("Datos Sensores");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(160, 10, 170, 32);

        labelHumedad.setText("Sensor Humedad:");
        getContentPane().add(labelHumedad);
        labelHumedad.setBounds(12, 62, 130, 15);

        labelProximidad.setText("Sensor Proximidad:");
        getContentPane().add(labelProximidad);
        labelProximidad.setBounds(160, 60, 160, 15);

        labelTemperatura.setText("Sensor Temperatura:");
        getContentPane().add(labelTemperatura);
        labelTemperatura.setBounds(350, 60, 170, 15);

        jLabel5.setText("Historial");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(12, 95, 120, 15);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Humedad", "Proximidad", "Temperatura"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 120, 453, 117);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelHumedad;
    private javax.swing.JLabel labelProximidad;
    private javax.swing.JLabel labelTemperatura;
    // End of variables declaration//GEN-END:variables

    public Float getValoresHumedad()
    {
        return valoresHumedad;
    }

    public void setValoresHumedad(Object valoresHumedad)
    {
        this.valoresHumedad = (Float) valoresHumedad;
    }

    public Float getValoresProximidad()
    {
        return valoresProximidad;
    }

    public void setValoresProximidad(Float valoresProximidad)
    {
        this.valoresProximidad = valoresProximidad;
    }

    public Float getValoresTemperatura()
    {
        return valoresTemperatura;
    }

    public void setValoresTemperatura(Float valoresTemperatura)
    {
        this.valoresTemperatura = valoresTemperatura;
    }

}
