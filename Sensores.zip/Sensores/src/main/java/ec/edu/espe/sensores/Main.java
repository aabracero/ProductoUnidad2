package ec.edu.espe.sensores;

public class Main
{
    public static void main(String[] args)
    {
        new Ventana();
    }
}
